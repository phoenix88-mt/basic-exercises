# basic-exercises
Basic exercises for beginners
